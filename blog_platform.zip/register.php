<?php
session_start();
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    include 'db.php';  // Соединение с базой данных
    $username = $_POST['username'];
    $email = $_POST['email'];
    $password = $_POST['password'];
    $password_hash = password_hash($password, PASSWORD_DEFAULT); // Хешируем пароль

    // Проверяем, существует ли уже пользователь с таким именем
    $stmt = $pdo->prepare("SELECT * FROM users WHERE username = ?");
    $stmt->execute([$username]);
    $existing_user = $stmt->fetch();

    if ($existing_user) {
        $error = "Пользователь с таким именем уже существует.";
    } else {
        // Вставляем нового пользователя в базу данных
        $stmt = $pdo->prepare("INSERT INTO users (username, email, password) VALUES (?, ?, ?)");
        $stmt->execute([$username, $email, $password_hash]);

        // Перенаправляем пользователя на страницу входа
        header('Location: login.php');
        exit;
    }
}
?>

<?php include 'header.php'; ?>
<main>
    <h1>Регистрация</h1>

    <form method="POST">
        <label for="username">Имя пользователя</label>
        <input type="text" name="username" required><br>

        <label for="email">Email</label>
        <input type="email" name="email" required><br>

        <label for="password">Пароль</label>
        <input type="password" name="password" required><br>

        <button type="submit">Зарегистрироваться</button>
    </form>

    <?php if (isset($error)) echo "<p>$error</p>"; ?>
</main>
<?php include 'footer.php'; ?>
