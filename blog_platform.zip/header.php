<header>
    <nav>
        <a href="index.php">Главная</a>
        <a href="create_blog.php">Создать блог</a>
        <a href="blogs_list.php">Все блоги</a>
        <?php if (isset($_SESSION['user_id'])): ?>
            <a href="profile.php">Профиль</a> <!-- Добавляем ссылку на профиль -->
        <?php else: ?>
            <a href="login.php">Войти</a>
            <a href="register.php">Регистрация</a>
        <?php endif; ?>
    </nav>
</header>

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Блог Платформа</title>
    <link rel="stylesheet" href="styles.css"> <!-- Подключение стилей -->
</head>