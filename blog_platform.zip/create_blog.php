<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}

include 'db.php';  // Соединение с базой данных

$user_id = $_SESSION['user_id'];

// Проверка, существует ли пользователь
$stmt_check_user = $pdo->prepare("SELECT id FROM users WHERE id = ?");
$stmt_check_user->execute([$user_id]);
$user_exists = $stmt_check_user->fetch();

if (!$user_exists) {
    die("Пользователь не найден.");
}

// Обработка формы добавления блога
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $title = $_POST['title'];
    $content = $_POST['content'];

    // Вставляем новый блог в базу данных
    $stmt = $pdo->prepare("INSERT INTO blogs (user_id, title, content) VALUES (?, ?, ?)");
    $stmt->execute([$user_id, $title, $content]);

    // Перенаправляем на страницу с блогами
    header('Location: blogs_list.php');
}
?>

<?php include 'header.php'; ?>
<main>
    <h1>Создать новый блог</h1>

    <form method="POST">
        <label for="title">Заголовок</label>
        <input type="text" name="title" required><br>

        <label for="content">Содержание</label>
        <textarea name="content" required></textarea><br>

        <button type="submit">Создать блог</button>
    </form>
</main>

<?php include 'footer.php'; ?>
