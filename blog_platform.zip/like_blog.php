<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}

include 'db.php';  // Соединение с базой данных

$blog_id = $_GET['blog_id'];
$user_id = $_SESSION['user_id'];

// Проверяем, не поставил ли пользователь уже лайк
$stmt = $pdo->prepare("SELECT * FROM likes WHERE user_id = ? AND blog_id = ?");
$stmt->execute([$user_id, $blog_id]);
$like = $stmt->fetch();

if ($like) {
    // Если лайк уже поставлен, убираем его
    $stmt = $pdo->prepare("DELETE FROM likes WHERE user_id = ? AND blog_id = ?");
    $stmt->execute([$user_id, $blog_id]);
} else {
    // Если лайк не поставлен, ставим его
    $stmt = $pdo->prepare("INSERT INTO likes (user_id, blog_id) VALUES (?, ?)");
    $stmt->execute([$user_id, $blog_id]);
}

header('Location: blogs_list.php');  // Перенаправляем обратно на список блогов
?>