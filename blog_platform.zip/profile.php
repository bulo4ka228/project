<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}

include 'db.php';  // Соединение с базой данных

$user_id = $_SESSION['user_id'];

// Получаем данные пользователя
$stmt = $pdo->prepare("SELECT * FROM users WHERE id = ?");
$stmt->execute([$user_id]);
$user = $stmt->fetch();

// Получаем количество лайков, поставленных пользователем
$stmt_likes = $pdo->prepare("SELECT COUNT(*) AS like_count FROM likes WHERE user_id = ?");
$stmt_likes->execute([$user_id]);
$like_count = $stmt_likes->fetch()['like_count'];

// Получаем количество комментариев пользователя
$stmt_comments = $pdo->prepare("SELECT COUNT(*) AS comment_count FROM comments WHERE user_id = ?");
$stmt_comments->execute([$user_id]);
$comment_count = $stmt_comments->fetch()['comment_count'];

// Обработка формы редактирования профиля
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $city = $_POST['city'];
    $age = $_POST['age'];
    $description = $_POST['description'];

    // Обновляем информацию в базе данных
    $stmt = $pdo->prepare("UPDATE users SET city = ?, age = ?, description = ? WHERE id = ?");
    $stmt->execute([$city, $age, $description, $user_id]);

    // Перезагружаем страницу с обновленными данными
    header('Location: profile.php');
}
?>

<?php include 'header.php'; ?>

<main>
    <h1>Личный кабинет</h1>
    <p><strong>Количество лайков:</strong> <?php echo $like_count; ?></p>
    <p><strong>Количество комментариев:</strong> <?php echo $comment_count; ?></p>

    <h2>Редактировать профиль</h2>
    <form method="POST">
        <label for="city">Город:</label>
        <input type="text" name="city" value="<?php echo htmlspecialchars($user['city']); ?>" required><br>

        <label for="age">Возраст:</label>
        <input type="number" name="age" value="<?php echo htmlspecialchars($user['age']); ?>" required><br>

        <label for="description">Описание:</label>
        <textarea name="description"><?php echo htmlspecialchars($user['description']); ?></textarea><br>

        <button type="submit">Сохранить</button>
    </form>
</main>

<?php include 'footer.php'; ?>
