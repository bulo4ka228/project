<?php
session_start();
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    include 'db.php';  // Соединение с базой данных
    $username = $_POST['username'];
    $password = $_POST['password'];

    $stmt = $pdo->prepare("SELECT * FROM users WHERE username = ?");
    $stmt->execute([$username]);
    $user = $stmt->fetch();

    if ($user && password_verify($password, $user['password'])) {
        $_SESSION['user_id'] = $user['id'];
        header('Location: index.php');  // Перенаправляем на главную страницу
    } else {
        $error = "Неверное имя пользователя или пароль";
    }
}
?>

<?php include 'header.php'; ?>
<main>
    <h1>Вход</h1>
    <form method="POST">
        <label for="username">Имя пользователя</label>
        <input type="text" name="username" required><br>

        <label for="password">Пароль</label>
        <input type="password" name="password" required><br>

        <button type="submit">Войти</button>
    </form>
    <?php if (isset($error)) echo "<p>$error</p>"; ?>
</main>
<?php include 'footer.php'; ?>
