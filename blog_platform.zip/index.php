<?php
include 'db.php';  // Соединение с базой данных

// Получаем все блоги
$stmt = $pdo->prepare("SELECT blogs.title, blogs.content, blogs.created_at, users.username 
                       FROM blogs 
                       JOIN users ON blogs.user_id = users.id");
$stmt->execute();
$blogs = $stmt->fetchAll();

// Подключаем шапку
include 'header.php';
?>

<main>
    <h1>Добро пожаловать на платформу для блогов разработчиков!</h1>
    <p>Здесь вы можете публиковать свои блоги и делиться мыслями с миром.</p>

    <?php if (count($blogs) > 0): ?>
        <ul>
            <?php foreach ($blogs as $blog): ?>
                <li>
                    <h2><?php echo htmlspecialchars($blog['title']); ?></h2>
                    <p><strong>Автор:</strong> <?php echo htmlspecialchars($blog['username']); ?></p>
                    <p><strong>Дата публикации:</strong> <?php echo $blog['created_at']; ?></p>
                    <p><strong>Содержание:</strong> <?php echo nl2br(htmlspecialchars($blog['content'])); ?></p>
                </li>
            <?php endforeach; ?>
        </ul>
    <?php else: ?>
        <p>Нет блогов для отображения.</p>
    <?php endif; ?>
</main>

<?php
// Подключаем футер
include 'footer.php';
?>