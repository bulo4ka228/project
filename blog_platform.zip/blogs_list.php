<?php
include 'db.php';  // Соединение с базой данных

// Получаем все блоги
$stmt = $pdo->prepare("SELECT blogs.id, blogs.title, blogs.content, blogs.created_at, users.username 
                       FROM blogs 
                       JOIN users ON blogs.user_id = users.id");
$stmt->execute();
$blogs = $stmt->fetchAll();

include 'header.php';
?>

<main>
    <h1>Блоги пользователей</h1>

    <?php foreach ($blogs as $blog): ?>
        <h2><?php echo htmlspecialchars($blog['title']); ?></h2>
        <p><strong>Автор:</strong> <?php echo htmlspecialchars($blog['username']); ?></p>
        <p><strong>Дата:</strong> <?php echo $blog['created_at']; ?></p>
        <p><?php echo nl2br(htmlspecialchars($blog['content'])); ?></p>

        <!-- Форма для добавления комментария -->
        <form action="add_comment.php" method="POST">
            <input type="hidden" name="blog_id" value="<?php echo $blog['id']; ?>">
            <textarea name="content" placeholder="Оставить комментарий" required></textarea>
            <button type="submit">Комментировать</button>
        </form>

        <!-- Показ комментариев -->
        <?php
        $stmt_comments = $pdo->prepare("SELECT comments.content, comments.created_at, users.username 
                                       FROM comments 
                                       JOIN users ON comments.user_id = users.id 
                                       WHERE comments.blog_id = ?");
        $stmt_comments->execute([$blog['id']]);
        $comments = $stmt_comments->fetchAll();
        ?>
        <h3>Комментарии:</h3>
        <?php if (count($comments) > 0): ?>
            <?php foreach ($comments as $comment): ?>
                <p><strong><?php echo htmlspecialchars($comment['username']); ?></strong> (<?php echo $comment['created_at']; ?>):</p>
                <p><?php echo nl2br(htmlspecialchars($comment['content'])); ?></p>
            <?php endforeach; ?>
        <?php else: ?>
            <p>Нет комментариев.</p>
        <?php endif; ?>
        <hr>
    <?php endforeach; ?>
</main>

<?php
include 'footer.php';
?>
