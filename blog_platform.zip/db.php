<?php
$host = 'localhost';
$dbname = 'blog_platform';
$username = 'root'; // по умолчанию в XAMPP
$password = ''; // по умолчанию в XAMPP

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    echo 'Ошибка подключения: ' . $e->getMessage();
}
?>