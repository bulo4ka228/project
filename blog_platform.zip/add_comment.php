<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}

include 'db.php';  // Соединение с базой данных

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $user_id = $_SESSION['user_id'];
    $blog_id = $_POST['blog_id'];
    $content = $_POST['content'];

    // Добавляем комментарий в базу данных
    $stmt = $pdo->prepare("INSERT INTO comments (user_id, blog_id, content) VALUES (?, ?, ?)");
    $stmt->execute([$user_id, $blog_id, $content]);

    header('Location: blogs_list.php');  // Перенаправляем обратно на список блогов
}
?>